// Deamonte Irving
// 9/14/2018
// COP2000_HW1
// This program calcalates the ingredients to make pie crusts.
#include <iostream>
#include <iomanip>
using namespace std;

int main()

{
	//Constants
	const float flour_1 = 2.5;
	const float sugar_1 = 1.33;
	const float salt_1 = .50;
	const float butter_1 = .875;
	const float eggs_1 = 1;

	//Variable for user input
	float number_of_pies;

	//Question to be displayed to user
	cout << "How many pies do you wish to make?\n";
	cin >> number_of_pies;
	cout << "\n";
	cout << "\n";

	//Pie shop heading
	cout << "Welcome to Malachi's Pie Shop - Pie Crust Recipe" << endl;
	cout << "------------------------------------------------" << endl;

	cout << setprecision(4) << showpoint << "You wish to make " << number_of_pies << " pies.\n" << endl;



	//Dispaying the new results
	cout << "Flour  " << setprecision(4) << showpoint << flour_1 * number_of_pies << " Cups       " << endl;
	cout << "Sugar  " << setprecision(4) << showpoint << sugar_1 * number_of_pies << " Tablespoon " << endl;
	cout << "Salt   " << setprecision(4) << showpoint << salt_1 * number_of_pies << " Tablespoon " << endl;
	cout << "Butter " << setprecision(4) << showpoint << butter_1 * number_of_pies << " Cups       " << endl;
	cout << "Eggs   " << setprecision(4) << showpoint << eggs_1 * number_of_pies << " Large      " << endl;

	system("pause");
	return 0;

}